title: 支付demo篇（12）-支付对接 -退款（1）
date: '2019-09-06 19:02:39'
updated: '2019-09-06 20:46:38'
tags: [JAVA, 支付]
permalink: /articles/2019/09/06/1567767759686.html
---
##### 添加统一支付退款controller（IndexController）
```
 @RequestMapping(value = "/refund",method = RequestMethod.POST)
    @ResponseBody
    public Object refund() {
        //为方便以及处理回调都采用该方式
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        Map<String, String> params = RequestUtil.convertRequestParamsToMap(request);
        return payService.unifiedOrder(JSONObject.parseObject(JSONObject.toJSONString(params), PayOrderVo.class));
    }
```

##### 添加统一支付退款接口IPayService
```
 /**
     * 统一退款接口
     * @param payOrderVo
     * @return
     */
    Map refund(PayOrderVo payOrderVo);
```

##### 添加统一支付退款接口实现PayService
```
 @Override
    public Map refund(PayOrderVo payOrderVo) {
        //统一生成支付退款操作
        if(payOrderVo.getPayType().equals(PayConstant.PayType.ALI_PAY)){
              return this.aliPayRefund(payOrderVo);
        }

        return null;
    }

```
##### 添加支付宝退款接口IPayService
```
 /**
     * 支付宝退款
     * @param payOrderVo
     * @return
     */
    Map aliPayRefund(PayOrderVo payOrderVo);
```

##### 添加支付宝退款接口实现PayService
```
 @Override
    public Map aliPayRefund(PayOrderVo payOrderVo) {
        try{
            Map<String,String> params = new HashMap<String,String>();
            //商户订单号 这个为支付请求我们生成的ID
            params.put("out_trade_no", payOrderVo.getOrderId());
            //支付宝在支付成功后返回的支付凭证ID 由支付宝生成
            params.put("trade_no", payOrderVo.getPayId());
            //退款预生成的流水号 由系统保证唯一
            params.put("out_request_no", CoreUtil.MD5(UUID.randomUUID().toString()));
            //退款金额 demo使用订单金额
            params.put("refund_amount", payOrderVo.getAmount()+"");
            AlipayClient alipayClient = new DefaultAlipayClient(BaseValue.ALI_GATEWAY,BaseValue.ALI_PAY_APP_ID,BaseValue.ALI_PAY_PRIVATE_KEY,BaseValue.ALI_FORMAT,BaseValue.ALI_CHARSET,BaseValue.ALI_PAY_PUBLIC_KEY,BaseValue.ALI_SIGN_TYPE);
            AlipayTradeRefundRequest request = new AlipayTradeRefundRequest();
            request.setBizContent(JSONObject.toJSONString(params));
            AlipayTradeRefundResponse back = alipayClient.execute(request);
            logger.info("【支付宝退款信息 back = {} 】", back);
            String body = back.toString();
            if(back == null || !back.isSuccess()){
                logger.info("【支付宝退款失败  {} 】", back.isSuccess());
            }
            if(back.getCode().equals("10000")){
                logger.info("【支付订单 退款 {} 成功 】",payOrderVo.getAmount());
            }
            if(back.getSubCode()!=null && back.getSubCode().equals("ACQ.SYSTEM_ERROR")){
                logger.info("【支付订单  退款 {} 超时 】",payOrderVo.getAmount());
            }
        }catch(Exception e){
            logger.info("【支付宝退款失败  {} 】", e.getMessage());
        }
        return null;
    }
```

##### 添加微信支付证书加载依赖
```
    compile group: 'org.apache.httpcomponents', name: 'httpclient', version: '4.5.9'
    compile group: 'org.apache.httpcomponents', name: 'httpclient-cache', version: '4.5.9'
    compile group: 'org.apache.httpcomponents', name: 'httpcore', version: '4.4.11'
    compile group: 'org.apache.httpcomponents', name: 'httpmime', version: '4.5.9'
```

##### 添加微信支付证书远程文件加载工具类
```
public class FileUtil {

    private static Logger logger = LoggerFactory.getLogger(FileUtil.class);

    /**
     * 获取流
     * @param filePath
     * @return
     */
    public static ByteArrayInputStream getInputStream(String filePath) {
        // 输入流对象
        InputStream in = null;
        // 字节数组输出流
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            URL url = new URL(filePath);
            URLConnection connection = url.openConnection();
            in = connection.getInputStream();

            int len = -1;
            byte[] data = new byte[1024];
            while ((len = in.read(data)) != -1) {
                out.write(data, 0, len);
            }
        } catch (MalformedURLException me) {
            logger.error("创建链接失败,message={}", me.getMessage());
        } catch (IOException ie) {
            logger.error("IO操作失败,message={}", ie.getMessage());
        } finally {
            if (in != null) {
                try {
                    // 关闭输入流
                    in.close();
                } catch (IOException e) {
                    logger.error("输入流关闭失败,message={}", e.getMessage());
                }
            }
            if (out != null) {
                try {
                    // 关闭输出流
                    out.close();
                } catch (IOException e) {
                    logger.error("输出流关闭失败,message={}", e.getMessage());
                }
            }
        }
        return new ByteArrayInputStream(out.toByteArray());
    }
}
```

##### 添加微信退款地址BaseValue
```
   /**
     * 微信退款地址
     */
    public static final String WX_REFUND_URL = "https://api.mch.weixin.qq.com/secapi/pay/refund";
```
