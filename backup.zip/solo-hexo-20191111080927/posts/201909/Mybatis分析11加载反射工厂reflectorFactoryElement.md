title: Mybatis分析（11）-加载反射工厂reflectorFactoryElement
date: '2019-09-04 14:40:49'
updated: '2019-09-04 15:35:28'
tags: [Mybatis]
permalink: /articles/2019/09/04/1567579249302.html
---
```
  private void reflectorFactoryElement(XNode context) throws Exception {
    //如果定义了
    if (context != null) {
      //获取type的值
      String type = context.getStringAttribute("type");
      //实例化
      ReflectorFactory factory = (ReflectorFactory) resolveClass(type).getDeclaredConstructor().newInstance();
      //赋值
      configuration.setReflectorFactory(factory);
    }
  }
```

* mybatis为了更好的灵活性，以及加载各种插件类等，支持可以由用户自定义反射工厂
* 实际上我们使用mybatis自带的反射工厂即可
* 只需要实现ReflectorFactory，默认的反射工厂是DefaultReflectorFactory

