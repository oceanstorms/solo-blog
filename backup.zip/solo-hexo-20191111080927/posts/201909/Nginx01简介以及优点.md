title: Nginx-01-简介以及优点
date: '2019-09-08 19:47:56'
updated: '2019-09-08 19:47:56'
tags: [Nginx, JAVA]
permalink: /articles/2019/09/08/1567943276878.html
---
![](https://img.hacpai.com/bing/20190228.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

##### 简介 
- Nginx 可以在大多数 [Unix](https://baike.baidu.com/item/Unix)Linux OS 上编译运行，并有 [Windows](https://baike.baidu.com/item/Windows) 移植版。 Nginx 的1.4.0稳定版已经于2013年4月24日发布，一般情况下，对于新建站点，建议使用最新稳定版作为生产版本，已有站点的升级急迫性不高。 
- Nginx 是一个很强大的高性能[Web](https://baike.baidu.com/item/Web/150564)和[反向代理](https://baike.baidu.com/item/%E5%8F%8D%E5%90%91%E4%BB%A3%E7%90%86)服务，它具有很多非常优越的特性：

- 在连接高并发的情况下，Nginx是[Apache](https://baike.baidu.com/item/Apache/6265)服务不错的替代品：Nginx在美国是做虚拟主机生意的老板们经常选择的软件平台之一。能够支持高达 50,000 个并发连接数的响应，感谢Nginx为我们选择了 epoll and kqueue作为开发模型。

##### 优点
 
* 高并发，高性能
* 可扩展性
* 高可靠
* 热部署
* BSD许可证（可以修改源代码用于商业环境）

##### 组成
* Nginx二进制可执行文件
  由各模块源码编译出的一个文件
* Nginx.conf配置文件
   控制nginx的行为
* access.log访问日志
   记录每一条Http请求信息
* error.log错误日志
   主要用于定位问题

 
