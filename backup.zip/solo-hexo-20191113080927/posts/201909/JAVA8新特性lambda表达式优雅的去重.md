title: JAVA8新特性lambda表达式（优雅的去重）
date: '2019-09-01 18:13:59'
updated: '2019-09-01 18:13:59'
tags: [JAVA8]
permalink: /articles/2019/09/01/1567332839844.html
---
###### 字符串去重
```
List<String> dataList = list.stream().distinct().collect(Collectors.toList());

```
###### 对象属性去重
```
//根据id去重
personList = personList.stream().collect(Collectors.collectingAndThen(Collectors.toCollection(
                // 利用 TreeSet 的排序去重构造函数来达到去重元素的目的
                // 根据firstName去重
                () -> new TreeSet<>(Comparator.comparing(Person::getName))), ArrayList::new));

```
