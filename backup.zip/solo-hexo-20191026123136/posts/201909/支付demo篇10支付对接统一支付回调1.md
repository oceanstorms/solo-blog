title: 支付demo篇（10）-支付对接 - 统一支付回调（1）
date: '2019-09-06 19:34:20'
updated: '2019-09-06 20:10:19'
tags: [JAVA, 支付]
permalink: /articles/2019/09/06/1567769660274.html
---
##### 添加请求参数解析RequestUtil
```
  /**
     * 微信获取post数据
     * @param request
     * @return
     */
    public static String getPostStr(HttpServletRequest request) {
        StringBuffer sb = new StringBuffer();
        try {
            InputStream is = request.getInputStream();
            InputStreamReader isr = new InputStreamReader(is, "UTF-8");
            BufferedReader br = new BufferedReader(isr);
            String s = "";
            while ((s = br.readLine()) != null) {
                sb.append(s);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        String xml = sb.toString();
        return xml;

    }

```
##### 添加线程处理工具
```
public class ThreadManager {
    public static ThreadPool instance;
    // 耗时比较长的线程池   用来请求网络
    private ThreadPoolExecutor longExecutor;
    // 比较短的线程池    用来加载本地数据
    private ThreadPoolExecutor shortExecutor;

    // 获取单例的线程池对象
    public static ThreadPool getInstance() {
        if (instance == null) {
            synchronized (ThreadManager.class) {
                if (instance == null) {
                    // 获取处理器数量
                    int cpuNum = Runtime.getRuntime().availableProcessors();
                    // 根据cpu数量,计算出合理的线程并发数
                    int threadNum = cpuNum * 2 + 1;
                    //默认是双核的cpu 每个核心走一个线程 一个等待线程
                    instance = new ThreadPool(threadNum-1, threadNum, Integer.MAX_VALUE);
                }
            }
        }
        return instance;
    }

    public static class ThreadPool {
        private ThreadPoolExecutor mExecutor;
        private int corePoolSize;
        private int maximumPoolSize;
        private long keepAliveTime;

        private ThreadPool(int corePoolSize, int maximumPoolSize, long keepAliveTime) {
            this.corePoolSize = corePoolSize;
            this.maximumPoolSize = maximumPoolSize;
            this.keepAliveTime = keepAliveTime;
        }

        public void execute(Runnable runnable) {
            if (runnable == null) {
                return;
            }
            if (mExecutor == null) {
                mExecutor = new ThreadPoolExecutor(corePoolSize,// 核心线程数
                        maximumPoolSize, // 最大线程数
                        keepAliveTime, // 闲置线程存活时间
                        TimeUnit.MILLISECONDS,// 时间单位
                        new LinkedBlockingDeque<Runnable>(Integer.MAX_VALUE),// 线程队列
                        Executors.defaultThreadFactory(),// 线程工厂
                        new ThreadPoolExecutor.AbortPolicy() {// 队列已满,而且当前线程数已经超过最大线程数时的异常处理策略
                            @Override
                            public void rejectedExecution(Runnable r, ThreadPoolExecutor e) {
                                super.rejectedExecution(r, e);
                            }
                        }
                );
            }
            mExecutor.execute(runnable);
        } 
        // 从线程队列中移除对象
        public void cancel(Runnable runnable) {
            if (mExecutor != null) {
                mExecutor.getQueue().remove(runnable);
            }
        }
    }
}
```

##### 添加统一支付回调参数封装PayBackVo
```
public class PayBackVo implements Serializable {

    /*------支付宝参数-----*/

    private String gmt_create;

    private String charset;

    private String seller_email;

    private String notify_time;

    private String suject;

    private String body;

    private String buyer_id;

    private String version;

    private String notify_id;

    private String notify_type;

    private String total_amount;

    private String trade_status;

    private String trade_no;

    private String auth_app_id;

    private String buyer_login_id;

    private String app_id;

    private String sign_type;

    private String seller_id;

    /*---------微信支付回调参数-------------*/

    private String transaction_id;

    private String nonce_str;

    private String bank_type;

    private String openid;

    private String fee_type;

    private String mch_id;

    private String cash_fee;

    private String device_info;

    private String appid;

    private String total_fee;

    private String trade_type;

    private String result_code;

    private String is_subscribe;

    private String return_code;

    /*--------------支付宝微信回调公用参数----------------*/

    private String sign;

    private String out_trade_no;
    ....
}
```
##### 添加统一支付回调接口IPayService
```
  /**
     * 统一回调接口
     * @param param
     * @return
     */
    String unifiedNotify(Map param);
```
##### 添加Bean操作工具类
```
public class MyBeanUtil {

    public static <T> T createBean(Object origObj, Class<T> destClazz) {
        String jsonStr = JSON.toJSONString(origObj);
        return JSON.parseObject(jsonStr, destClazz);
    }

}

```
##### 添加统一支付回调接口实现PayService
```
 @Override
    public Map refund(PayOrderVo payOrderVo) {
        //统一生成支付退款操作
        //支付宝退款
        if(payOrderVo.getPayType().equals(PayConstant.PayType.ALI_PAY)){
              return this.aliPayRefund(payOrderVo);
        }
        //微信退款
        if(payOrderVo.getPayType().equals(PayConstant.PayType.WX_APPLET_PAY) 
                || payOrderVo.getPayType().equals(PayConstant.PayType.WX_PAY){
            return this.aliPayRefund(payOrderVo);
        }
        return null;
    }

```

##### 添加统一支付回调controller（IndexController）
```
@RequestMapping(value = "/unifiedNotify",method = RequestMethod.POST)
    @ResponseBody
    public String unifiedNotify(){
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        Map<String, String> params = RequestUtil.convertRequestParamsToMap(request);
        if(params==null || params.size()==0){
            String postXml = RequestUtil.getPostStr(request);
            try {
                params = XMLBeanUtil.doXMLParse(postXml);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return payService.unifiedNotify(params);
    }
```
