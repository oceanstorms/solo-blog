title: 支付demo篇（04）-支付对接 -支付宝APP支付
date: '2019-09-06 09:03:09'
updated: '2019-09-06 09:03:09'
tags: [JAVA, 支付]
permalink: /articles/2019/09/06/1567731789740.html
---
##### 更改请求接口IndexController
```
@RequestMapping(value = "/pay",method = RequestMethod.POST)
    @ResponseBody
    public Object aliQrPay() {
        //为方便以及处理回调都采用该方式
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        Map<String, String> params = RequestUtil.convertRequestParamsToMap(request);
        return payService.unifiedOrder(JSONObject.parseObject(JSONObject.toJSONString(params), PayOrderVo.class));
    }
```
* 统一支付入口只需要将传入的order对象，根据里面的类型进行不同的支付

##### 添加支付渠道码BaseValue
```
   /**
     * 支付宝支付渠道码
     */
    public static final String QUICK_MSECURITY_PAY = "QUICK_MSECURITY_PAY";

```

##### 添加支付接口IPayService
```
 /**
     * 支付宝APP支付
     * @param payOrderVo
     * @return
     */
    Map aliAppPay(PayOrderVo payOrderVo);
```

##### 添加支付接口实现PayService
```
 @Override
    public Map aliQrPay(PayOrderVo payOrderVo) {
        //创建订单
        AlipayClient alipayClient = new DefaultAlipayClient(BaseValue.ALI_GATEWAY,BaseValue.ALI_PAY_APP_ID,BaseValue.ALI_PAY_PRIVATE_KEY,BaseValue.ALI_FORMAT,BaseValue.ALI_CHARSET,BaseValue.ALI_PAY_PUBLIC_KEY,BaseValue.ALI_SIGN_TYPE);
        AlipayTradePrecreateRequest request = new AlipayTradePrecreateRequest();
        //构建公共参数 设置回调参数
        request.setNotifyUrl(BaseValue.SYSTEM_NOTIFY_URL);
        //构建业务参数
        HashMap<String,String> map = new HashMap<String,String>(){{
            //out_trade_no 作为整个系统的支付凭证 需要全平台唯一 demo此处使用UUID
            put("out_trade_no",UUID.randomUUID().toString());
            put("total_amount",payOrderVo.getAmount()+"");
            put("subject",payOrderVo.getSubject());
            put("body",payOrderVo.getBody()!=null?payOrderVo.getBody():payOrderVo.getSubject());
            //store_id 如果是多商户架构 建议为商户ID demo此处使用UUID
            put("store_id",UUID.randomUUID().toString());
            put("terminal_id",payOrderVo.getClientIp());
            //二维码失效时间根据需求自定义
            put("qr_code_timeout_express","90m");
        }};
        request.setBizContent(JSONObject.toJSONString(map));
        AlipayTradePrecreateResponse response = null;
        try {
            response = alipayClient.execute(request);
        } catch (Exception e) {
            logger.info("【支付宝获取二维码失败 {}】",e.getMessage());
        }
        if(response!=null && response.isSuccess()){
            return JSONObject.parseObject(JSONObject.toJSONString(response), Map.class);
        } else {
            logger.info("【支付宝获取二维码失败 {}】",response.toString());
        }
        return null;
    }

    @Override
    public Map aliAppPay(PayOrderVo payOrderVo) {
        /**
         * 扫码支付和APP使用的参数构建不同 请自行选择
         */
        AlipayClient alipayClient = new DefaultAlipayClient(BaseValue.ALI_GATEWAY,BaseValue.ALI_PAY_APP_ID,BaseValue.ALI_PAY_PRIVATE_KEY,BaseValue.ALI_FORMAT,BaseValue.ALI_CHARSET,BaseValue.ALI_PAY_PUBLIC_KEY,BaseValue.ALI_SIGN_TYPE);
        AlipayTradeAppPayRequest request = new AlipayTradeAppPayRequest();
        request.setNotifyUrl(BaseValue.SYSTEM_NOTIFY_URL);
        //构建业务参数
        AlipayTradeAppPayModel model = new AlipayTradeAppPayModel();
        model.setBody(payOrderVo.getBody()!=null?payOrderVo.getBody():payOrderVo.getSubject());
        model.setSubject(payOrderVo.getSubject());
        //请保证OutTradeNo值每次保证唯一 demo使用UUID 自行实现
        model.setOutTradeNo(UUID.randomUUID().toString());
        //store_id 如果是多商户架构 建议为商户ID demo此处使用UUID
        model.setStoreId(UUID.randomUUID().toString());
        model.setTotalAmount(payOrderVo.getAmount()+"");
        //支付渠道码
        model.setProductCode(BaseValue.QUICK_MSECURITY_PAY);
        request.setBizModel(model);
        AlipayTradeAppPayResponse response = null;
        try {
            response = alipayClient.sdkExecute(request);
            if(response!=null && response.isSuccess()){
                //ios 安卓只需要 response.getBody() 即可 直接返回 也可自行封装
                String body = response.getBody();
                return new HashMap<String, String>() {{
                    put("data", body);
                }};
            }else{
                logger.info("【支付宝获取APP支付参数失败 {}】",response.toString());
            }
        } catch (AlipayApiException e) {
            logger.info("【支付宝获取APP支付参数失败 {}】",e.getMessage());
        }
        return null;
    }
```
##### 测试支付宝APP支付
```
http://127.0.0.1:8080/pay?orderId=123456789&userId=123456789&mobile=123456789&openId=123456789&payType=ALI_PAY&tradeType=APP&trxType=XF&subject=测试支付宝二维码支付subject&body=测试支付宝二维码支付body&clientIp=127.0.0.1&amount=0.01&remark=测试支付宝二维码支付
```
* 返回类似数据表示成功
![image.png](https://img.hacpai.com/file/2019/09/image-1c0a77be.png)

#### 测试支付
* 使用阿里官方提供的支付调试安装包将参数内容复制进去拉起支付宝进行支付
* 示例
![image.png](https://img.hacpai.com/file/2019/09/image-cf3af705.png)

