title: 支付demo篇（08）-支付对接 -微信小程序支付基本环境
date: '2019-09-06 15:30:59'
updated: '2019-09-06 15:31:09'
tags: [JAVA, 支付]
permalink: /articles/2019/09/06/1567755059224.html
---
##### 添加微信小程序支付常量BaseValue
```
 /**
     * 微信小程序支付APPID
     */
    public static String WX_APPLET_APP_ID = "*********************";

    /**
     * 微信小程序支付私钥ID
     */
    public static String WX_APPLET_MCH_ID = "*********************";

    /**
     * 微信小程序支付私钥
     */
    public static String WX_APPLET_MCH_KEY = "*********************";

    /**
     * 微信小程序支付加密方式
     */
    public static String WX_APPLET_SIGN_TYPE = "MD5";
```

 
