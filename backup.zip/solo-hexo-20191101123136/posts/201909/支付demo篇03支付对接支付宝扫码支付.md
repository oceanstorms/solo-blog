title: 支付demo篇（03）-支付对接 -支付宝扫码支付
date: '2019-09-05 19:34:36'
updated: '2019-09-05 19:34:36'
tags: [JAVA, 支付]
permalink: /articles/2019/09/05/1567683276503.html
---
#### 支付宝扫码支付官方文档
https://docs.open.alipay.com/194/106078

##### 添加支付宝依赖
https://www.lanzous.com/i6143cb
* 可以自行打入本地maven
* 引入依赖
```
dependencies {
    compile 'com.alibaba:fastjson:1.1.37'
    compile group: 'com.aliyun.sdk', name: 'pay', version: '1.0'
    compile group: 'net.sf.json-lib', name: 'json-lib', version: '2.4',classifier:'jdk15'
    compile("org.springframework.boot:spring-boot-starter-web:2.1.7.RELEASE")
    testCompile group: 'junit', name: 'junit', version: '4.12'
}
```

##### 添加支付配置项
```
public class BaseValue {

    /**
     * 支付宝APPID
     */
    public static String ALI_PAY_APP_ID = "***************";

    /**
     * 支付宝请求私钥
     */
    public static String ALI_PAY_PRIVATE_KEY = "***************";

    /**
     * 支付宝请求公钥
     */
    public static String ALI_PAY_PUBLIC_KEY = "***************";

    /**
     * 支付宝FORMAT
     */
    public static String ALI_FORMAT = "json";

    /**
     * 支付宝字符集
     */
    public static String ALI_CHARSET = "UTF-8";

    /**
     * 支付宝签名类型
     */
    public static String ALI_SIGN_TYPE = "***************";

    /**
     * 支付宝网关中心
     */
    public static String ALI_GATEWAY = "https://openapi.alipay.com/gateway.do";

    /**
     * 系统支付回调地址
     */
    public static String SYSTEM_NOTIFY_URL = "***************";


}
```


##### 添加支付宝二维码支付请求controller
```
 @RequestMapping(value = "/aliQrPay",method = RequestMethod.POST)
    @ResponseBody
    public Object aliQrPay() {
        //为方便以及处理回调都采用该方式
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        Map<String, String> params = RequestUtil.convertRequestParamsToMap(request);
        return payService.unifiedOrder(JSONObject.parseObject(JSONObject.toJSONString(params), PayOrderVo.class));
    }
```
##### 添加请求处理工具类
```
public class RequestUtil {

    /**
     * 将request中的参数转换成Map
     * @param request
     * @return
     */
    public static Map<String, String> convertRequestParamsToMap(HttpServletRequest request) {
        Map<String, String> retMap = new HashMap<String, String>();
        Set<Map.Entry<String, String[]>> entrySet = request.getParameterMap().entrySet();
        for (Map.Entry<String, String[]> entry : entrySet) {
            String name = entry.getKey();
            String[] values = entry.getValue();
            int valLen = values.length;

            if (valLen == 1) {
                retMap.put(name, values[0]);
            } else if (valLen > 1) {
                StringBuilder sb = new StringBuilder();
                for (String val : values) {
                    sb.append(",").append(val);
                }
                retMap.put(name, sb.toString().substring(1));
            } else {
                retMap.put(name, "");
            }
        }

        return retMap;
    }


}
```

##### 添加接口以及service
```
public interface IPayService {

    /**
     * 统一支付接口
     * @param payOrderVo
     * @return
     */
    Map unifiedOrder(PayOrderVo payOrderVo);

    /**
     * 支付宝二维码支付
     * @param payOrderVo
     * @return
     */
    Map aliQrPay(PayOrderVo payOrderVo);
}
```
```
@Service
public class PayService implements IPayService {

    private static Logger logger = LoggerFactory.getLogger(PayService.class);

    @Override
    public Map unifiedOrder(PayOrderVo payOrderVo) {
        //支付宝支付
        if(payOrderVo.getPayType().equals(PayConstant.PayType.ALI_PAY)){
            //扫码支付
            if (payOrderVo.getTradeType().equals(PayConstant.TradeType.QR)) {
                return this.aliQrPay(payOrderVo);
            }
        }
        return null;
    }

    @Override
    public Map aliQrPay(PayOrderVo payOrderVo) {
        //创建订单
        AlipayClient alipayClient = new DefaultAlipayClient(BaseValue.ALI_GATEWAY,BaseValue.ALI_PAY_APP_ID,BaseValue.ALI_PAY_PRIVATE_KEY,BaseValue.ALI_FORMAT,BaseValue.ALI_CHARSET,BaseValue.ALI_PAY_PUBLIC_KEY,BaseValue.ALI_SIGN_TYPE);
        AlipayTradePrecreateRequest request = new AlipayTradePrecreateRequest();
        //构建公共参数 设置回调参数
        request.setNotifyUrl(BaseValue.SYSTEM_NOTIFY_URL);
        //构建业务参数
        HashMap<String,String> map = new HashMap<String,String>(){{
            //out_trade_no 作为整个系统的支付凭证 需要全平台唯一 demo此处使用UUID
            put("out_trade_no",UUID.randomUUID().toString());
            put("total_amount",payOrderVo.getAmount()+"");
            put("subject",payOrderVo.getSubject());
            put("body",payOrderVo.getBody()!=null?payOrderVo.getBody():payOrderVo.getSubject());
            //store_id 如果是多商户架构 建议为商户ID demo此处使用UUID
            put("store_id",UUID.randomUUID().toString());
            put("terminal_id",payOrderVo.getClientIp());
            //二维码失效时间根据需求自定义
            put("qr_code_timeout_express","90m");
        }};
        request.setBizContent(JSONObject.toJSONString(map));
        AlipayTradePrecreateResponse response = null;
        try {
            response = alipayClient.execute(request);
        } catch (Exception e) {
            logger.info("【支付宝获取二维码失败 {}】",e.getMessage());
        }
        if(response!=null && response.isSuccess()){
            return JSONObject.parseObject(JSONObject.toJSONString(response), Map.class);
        } else {
            logger.info("【支付宝获取二维码失败 {}】",response.toString());
        }
        return null;
    }
}

```
##### 使用postman测试
```
http://127.0.0.1:8080/aliQrPay?orderId=123456789&userId=123456789&mobile=123456789&openId=123456789&payType=ALI_PAY&tradeType=QR&trxType=XF&subject=测试支付宝二维码支付subject&body=测试支付宝二维码支付body&clientIp=127.0.0.1&amount=0.01&remark=测试支付宝二维码支付
```
![image.png](https://img.hacpai.com/file/2019/09/image-2a09f540.png)

##### 返回信息
```
{

"msg": "Success",

"code": "10000",

"qrCode": "https://qr.alipay.com/bax03000yzha515rzs214083",

"success": true,

"outTradeNo": "bbab7dc7-867d-4110-ade5-0eb3257d56a0",

"errorCode": "10000",

"body": "{\"alipay_trade_precreate_response\":{\"code\":\"10000\",\"msg\":\"Success\",\"out_trade_no\":\"bbab7dc7-867d-4110-ade5-0eb3257d56a0\",\"qr_code\":\"https:\/\/qr.alipay.com\/bax03000yzha515rzs214083\"},\"sign\":\"FEnHlryAeoS6HcHd8hIGTHNVAZTfBDyJM47dGpj0Ctxy9YYZtieNbw+wYV6fTBXW1CDSiWCpz9zTKooODpLZGw/fxvrFi2/A9k4teoH+AiFf42RcKNLUL/naZ9AmP2GJSEtSOE6PtLkfFc91pHYXhmF4Ol0+WQ6tJ/l+gc0zwX4=\"}",

"params": {

"biz_content": "{\"body\":\"测试支付宝二维码支付body\",\"out_trade_no\":\"bbab7dc7-867d-4110-ade5-0eb3257d56a0\",\"qr_code_timeout_express\":\"90m\",\"store_id\":\"492b92b1-056a-4b5e-b5da-44fcbb547854\",\"subject\":\"测试支付宝二维码支付subject\",\"terminal_id\":\"127.0.0.1\",\"total_amount\":\"0.01\"}"

}

}
```

##### 使用在线生成二维码的工具将qrCode字段的值生成二维码使用支付宝进行支付
![image.png](https://img.hacpai.com/file/2019/09/image-ded7acd7.png)

##### 几点补充
* 1.参数没有进行封装需要自行封装
* 2.回调在讲完APP支付之后统一进行测试
* 3.由于只是demo很多东西以及参数没有进行细化，如果有需要请参考官方的支付文档
