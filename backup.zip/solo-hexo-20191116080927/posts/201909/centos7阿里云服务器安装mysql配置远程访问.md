title: centos7 阿里云服务器安装mysql 配置远程访问
date: '2019-09-01 18:17:42'
updated: '2019-09-01 18:17:42'
tags: [Linux]
permalink: /articles/2019/09/01/1567333062045.html
---
#### 使用yum安装 mysql版本5.7

#### 1.下载Yum Repository wget下载
```yml
wget -i -c http://dev.mysql.com/get/mysql57-community-release-el7-10.noarch.rpm
```
```yml
yum -y install mysql57-community-release-el7-10.noarch.rpm
```
#### 2.安装mysql服务(稍微需要一点时间)
```yml
yum -y install mysql-community-server
```
#### 3.启动mysql服务
```yml
systemctl start  mysqld.service
```
#### 4.查看mysql启动状态
```yml
systemctl status mysqld.service
```
 ![image.png](https://upload-images.jianshu.io/upload_images/10118469-7ba99ac9884bcc6a.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
#### 5.查询mysql随机生成的密码
```yml
grep "password" /var/log/mysqld.log
```
![image.png](https://upload-images.jianshu.io/upload_images/10118469-ff01efb688dc2fda.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

#### 6.进入mysql修改密码(默认强密码类型)
```yml
ALTER USER 'root'@'localhost' IDENTIFIED BY 'yourpassword';
```
#### 7.授权远程访问权限
```yml
GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' IDENTIFIED BY 'yourpassword';
```

#### 8.刷新权限
```yml
flush privileges;
```
#### 9.测试远程访问连接（需要阿里云的安全组开放端口）
