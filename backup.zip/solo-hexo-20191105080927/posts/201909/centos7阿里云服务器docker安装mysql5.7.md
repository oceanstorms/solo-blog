title: centos7 阿里云服务器docker安装mysql5.7
date: '2019-09-01 18:19:32'
updated: '2019-09-01 18:19:32'
tags: [Linux]
permalink: /articles/2019/09/01/1567333172459.html
---
#### centos7 阿里云服务器docker安装mysql5.7
#### docker安装参见[https://www.jianshu.com/p/fcaeb44c3314](https://www.jianshu.com/p/fcaeb44c3314)

* 搜索镜像
```
docker search mysql
```
![image.png](https://upload-images.jianshu.io/upload_images/10118469-9cd84e4461853773.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


* 拉取mysql5.7镜像
```
docker pull mysql:5.7 
```
![image.png](https://upload-images.jianshu.io/upload_images/10118469-5181d67c6971698d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

* 安装镜像 对外端口10001，docker内部端口3306，密码root可以自行更改
```
docker create --name mysql10001 -e MYSQL_ROOT_PASSWORD=root -p 10001:3306 mysql:5.7
```

* 启动mysql镜像
```
docker start mysql10001
```
* 测试链接
```
docker exec -it mysql10001 bash
mysql -uroot -p
```
* 连接成功
![image.png](https://upload-images.jianshu.io/upload_images/10118469-4c361587b406fb16.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![image.png](https://upload-images.jianshu.io/upload_images/10118469-fa567c5a5ec9f57e.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

