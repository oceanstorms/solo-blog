title: Mybatis分析（4）-属性解析propertiesElement
date: '2019-09-01 18:05:55'
updated: '2019-09-01 18:06:18'
tags: [Mybatis]
permalink: /articles/2019/09/01/1567332355505.html
---
```
org.apache.ibatis.builder.xml.XMLConfigBuilder#parseConfiguration
 private void propertiesElement(XNode context) throws Exception {
    if (context != null) {
      //加载properties节点
      Properties defaults = context.getChildrenAsProperties();
      String resource = context.getStringAttribute("resource");
      String url = context.getStringAttribute("url");
      //必须包含resource或者url
      if (resource != null && url != null) {
        throw new BuilderException("The properties element cannot specify both a URL and a resource based property file reference.  Please specify one or the other.");
      }
      if (resource != null) {
        defaults.putAll(Resources.getResourceAsProperties(resource));
      } else if (url != null) {
        defaults.putAll(Resources.getUrlAsProperties(url));
      }
      //合并Variables
      Properties vars = configuration.getVariables();
      if (vars != null) {
        defaults.putAll(vars);
      }
      //赋值XMLConfigBuilder.parser
      parser.setVariables(defaults);
      //赋值BaseBuilder.configuration
      configuration.setVariables(defaults);
    }
  }
```
* 可以发现这里加载了properties的节点然后合并Variables，最终把属性赋值给了XMLConfigBuilder.parser和BaseBuilder.configuration，这样就可以在整个配置中使用了。


