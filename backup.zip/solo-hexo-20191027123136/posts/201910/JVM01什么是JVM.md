title: JVM-01-什么是JVM？
date: '2019-10-25 22:21:52'
updated: '2019-10-25 22:21:52'
tags: [JAVA, JVM]
permalink: /articles/2019/10/25/1572013312494.html
---
* 定义
java程序运行环境（java二进制字节码的运行环境）
* 好处
  * 一次编写，到处运行
  * 自动内存管理，垃圾回收(gc)
  * 数组下标越界检查
  * 多态
