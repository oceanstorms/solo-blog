title: centos7 阿里云服务器docker安装nexus3
date: '2019-09-01 18:20:17'
updated: '2019-09-01 18:20:17'
tags: [Linux]
permalink: /articles/2019/09/01/1567333217431.html
---
#### centos7 阿里云服务器docker安装nexus3

* 搜索镜像
```
docker search nexus
```
```
[root@izj6c5c5zhif1dhww06p26z ~]# docker search nexus
NAME                                         DESCRIPTION                                     STARS               OFFICIAL            AUTOMATED
sonatype/nexus3                              Sonatype Nexus Repository Manager 3             648                                     
sonatype/nexus                               Sonatype Nexus                                  423                                     [OK]
clearent/nexus                                                                               21                                      
sonatype/nexus-iq-server                     Sonatype Nexus IQ Server                        13                                      
bradbeck/nexus-https                         Dockerized version of Nexus Repo Manager 3 w…   10                                      [OK]
baselibrary/nexus                            ThoughtWorks Docker Image: nexus                7                                       [OK]
cavemandaveman/nexus                         Sonatype Nexus container                        5                                       [OK]
frekele/nexus                                docker run --rm --name nexus -p 8081:8081 fr…   4                                       [OK]
shifudao/nexus3                              clone from nexus3 image but based from openj…   4                                       [OK]
fabric8/nexus                                                                                3                                       [OK]
madmuffin/nexus3                             Sonatype Nexus3 Milestone7 docker image         2                                       [OK]
fxinnovation/nexus3                          Sonatype Nexus 3 in a container                 1                                       [OK]
nexusstats/nexus-stats                                                                       1                                       
bradbeck/nexus-ha                            Sonatype Nexus Repository Manager 3 ready fo…   1                                       [OK]
cloud4t0r/nexus                              lastest nexus image optimized for ECS/AWS       1                                       
openshiftdemos/nexus                         Sonatype Nexus with JBoss Enterprise reposit…   1                                       
fjudith/nexus                                Dockerized Nexus Repository Manager based on…   0                                       [OK]
jenkinsxio/nexus                                                                             0                                       
ocadotechnology/nexus-data-pipeline-backup   Backup Nexus3 with AWS Data Pipeline and EFS…   0                                       [OK]
zbkio/nexus-noroot                           Nexus for Openshift                             0                                       
ocadotechnology/nexus-configurator           see: https://github.com/ocadotechnology/nexu…   0                                       
netspeedy/nexus                                                                              0                                       
trialgrid/nexus-docker                       Nexus docker image                              0                                       
ccdevopsford/nexus-resource                                                                  0                                       
nexus166/gobld                               https://github.com/nexus166/gobld               0                                       
[root@izj6c5c5zhif1dhww06p26z ~]# 
```

* 拉取镜像
```
docker pull sonatype/nexus3 
```
* 运行镜像
```
 docker run -d --name nexus3 --restart=always -p 10003:8088 -p 10004:8081 -p 10005:5000 -v /usr/local/java/maven:/nexus-data sonatype/nexus3
```

* 查看密码
```
cd /usr/local/java/maven
vim admin.password
```

* 运行界面
 
![image.png](https://upload-images.jianshu.io/upload_images/10118469-7f11359b87a3add8.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

* 配置阿里云代理仓库
![image.png](https://upload-images.jianshu.io/upload_images/10118469-0d9d0e1e154f0381.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![image.png](https://upload-images.jianshu.io/upload_images/10118469-2b123832d19c1dc6.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

* 将阿里云配置到首位
![image.png](https://upload-images.jianshu.io/upload_images/10118469-9d22f7a1562d2da1.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![image.png](https://upload-images.jianshu.io/upload_images/10118469-8b261c7c14e50229.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

