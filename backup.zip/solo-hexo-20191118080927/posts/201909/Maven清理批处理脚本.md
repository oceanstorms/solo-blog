title: Maven清理批处理脚本
date: '2019-09-01 18:16:09'
updated: '2019-09-01 18:16:09'
tags: [工具]
permalink: /articles/2019/09/01/1567332969162.html
---
```
@echo off  
@rem 切换到要删除的路径下  
  
set /p input=请输入maven仓库路径：  
set mavenDir=%input%  
  
%mavenDir:~0,1%:  
cd %mavenDir%  
  
echo 在%mavenDir%路径下已查找到所有以.lastUpdated结尾的文件  
dir /s/b .\*.lastUpdated>lastUpdated.txt  
  
echo 查找到的文件信息：%mavenDir%\lastUpdated.txt  
  
echo 请查看lastUpdated.txt，确认是否删除.lastUpdated文件所有目录，按任意键确认删除.  
pause>null  
  
@rem 遍历lastUpdated.txt文件，删除文件所在目录  
for /f "delims=" %%i in (lastUpdated.txt) do (  
   echo 文件记录:%%i  
   rd /s /q %%~dpi  
   echo 删除目录:%%~dpi  
)  
  
echo 成功删除所有.lastUpdated文件所在文件夹!  
  
del lastUpdated.txt  
echo 已清除临时文件%mavenDir%\lastUpdated.txt  
pause>null  
del null  
```
