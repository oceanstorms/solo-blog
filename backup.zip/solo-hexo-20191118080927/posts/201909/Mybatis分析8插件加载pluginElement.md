title: Mybatis分析（8）-插件加载pluginElement
date: '2019-09-01 18:08:01'
updated: '2019-09-01 18:08:01'
tags: [Mybatis]
permalink: /articles/2019/09/01/1567332481354.html
---
```
  private void pluginElement(XNode parent) throws Exception {
    if (parent != null) {
      for (XNode child : parent.getChildren()) {
        String interceptor = child.getStringAttribute("interceptor");
        Properties properties = child.getChildrenAsProperties();
        //将interceptor指定的名称解析为Interceptor类型
        Interceptor interceptorInstance = (Interceptor) resolveClass(interceptor).getDeclaredConstructor().newInstance();
        interceptorInstance.setProperties(properties);
        configuration.addInterceptor(interceptorInstance);
      }
    }
  }
```

* mybatis调用pluginElement(root.evalNode(“plugins”))加载插件
* 在不修改连接池源码的情况下，就可以借助mybatis的插件体系实现
* 插件在具体实现的时候，采用的是拦截器模式，要注册为mybatis插件，必须实现org.apache.ibatis.plugin.Interceptor接口，每个插件可以有自己的属性。interceptor属性值既可以完整的类名，也可以是别名，只要别名在typealias中存在即可，如果启动时无法解析，会抛出ClassNotFound异常。实例化插件后，将设置插件的属性赋值给插件实现类的属性字段。mybatis提供了两个内置的插件例子，如下所示：
![image.png](https://upload-images.jianshu.io/upload_images/10118469-c433d36193f6ac00.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)


