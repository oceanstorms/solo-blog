title: java发送腾讯企业邮件-可用于发送邮箱验证码
date: '2019-09-01 18:12:58'
updated: '2019-09-01 18:12:58'
tags: [消息推送]
permalink: /articles/2019/09/01/1567332778815.html
---
#### 第一步:
* 申请腾讯企业邮箱账号
![1.png](http://upload-images.jianshu.io/upload_images/10118469-c45b501408691111.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
#### 第二步:
登录 设置成员账号 成员账号进行登录发邮件
![2.png](http://upload-images.jianshu.io/upload_images/10118469-cd117f82b308c2db.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

![3.png](http://upload-images.jianshu.io/upload_images/10118469-dc17eb4799f8b7fb.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
* 回到原来的登录界面使用刚刚设置的成员账号进行登录
java中也是用这个账号进行发邮件的
#### 第三步:
可以查看官方提供的开发文档
![4.png](http://upload-images.jianshu.io/upload_images/10118469-2b2140de68c4c6bf.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

![5.png](http://upload-images.jianshu.io/upload_images/10118469-392cc503df5f091d.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

![6.png](http://upload-images.jianshu.io/upload_images/10118469-63675b5e11d2640c.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

![7.png](http://upload-images.jianshu.io/upload_images/10118469-442bbe3f5846783c.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
#### 第四步(忽略):
以下参数不需要修改(直接运行代码就可以 默认已经开启 ):
##POP3/SMTP协议
接收邮件服务器：pop.exmail.qq.com ，使用SSL，端口号995
发送邮件服务器：smtp.exmail.qq.com ，使用SSL，端口号465
海外用户可使用以下服务器
接收邮件服务器：hwpop.exmail.qq.com ，使用SSL，端口号995
发送邮件服务器：hwsmtp.exmail.qq.com ，使用SSL，端口号465
 
#### IMAP协议
接收邮件服务器：imap.exmail.qq.com  ，使用SSL，端口号993
发送邮件服务器：smtp.exmail.qq.com ，使用SSL，端口号465
海外用户可使用以下服务器
接收邮件服务器：hwimap.exmail.qq.com ，使用SSL，端口号993
发送邮件服务器：hwsmtp.exmail.qq.com ，使用SSL，端口号465

#### 第五步:
#### 不需要邮箱授权码 腾讯企业邮箱只需要账号密码就可以发送邮件
编写java代码:这里只是作为测试使用下面直接贴出我写代码 直接把账号密码改为你的就可以直接运行 需要导入mail.jar
```public class MailInfo implements Serializable {

    
  public static void main(String[] args) throws Exception {
        Properties prop = new Properties();
        //协议
        prop.setProperty("mail.transport.protocol", "smtp");
        //服务器
        prop.setProperty("mail.smtp.host", "smtp.exmail.qq.com");
        //端口
        prop.setProperty("mail.smtp.port", "465");
        //使用smtp身份验证
        prop.setProperty("mail.smtp.auth", "true");
        //使用SSL，企业邮箱必需！
        //开启安全协议
        MailSSLSocketFactory sf = null;
        try {
            sf = new MailSSLSocketFactory();
            sf.setTrustAllHosts(true);
        } catch (GeneralSecurityException e1) {
            e1.printStackTrace();
        }
        prop.put("mail.smtp.ssl.enable", "true");
        prop.put("mail.smtp.ssl.socketFactory", sf);
        //
        //获取Session对象
        Session s = Session.getDefaultInstance(prop,new Authenticator() {
            //此访求返回用户和密码的对象
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                PasswordAuthentication pa = new PasswordAuthentication("你的账号", "密码");
                return pa;
            }
        });
        //设置session的调试模式，发布时取消
        s.setDebug(true);
        MimeMessage mimeMessage = new MimeMessage(s);
        try {
            mimeMessage.setFrom(new InternetAddress("你的账号","你的账号"));
            mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress("接收账号"));
            //设置主题
            mimeMessage.setSubject("主题");
            mimeMessage.setSentDate(new Date());
            //设置内容
            mimeMessage.setText("正文内容");
            mimeMessage.saveChanges();
            //发送
            Transport.send(mimeMessage);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        
    }
}
```

